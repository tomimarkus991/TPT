﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kodune_töö1
{
    class Program
    {
        static void Main(string[] args)
        

            {
                Alg_03();
                Console.Write("\nVajuta suvalist klahvi\n\n");
                Console.ReadKey();
            }

            static void Alg_01()            // Harjutus 24
            {
                double põranda_pikkus = 56;     //meetrit 
                double värvitud_põrand = 22;   //meetrit
                double XkgVärv = 0;
            
                Console.WriteLine("Sisesta värvi kogus, mis kulus " + värvitud_põrand +  "m värvimiseks kg-ides");
                XkgVärv = Convert.ToDouble(Console.ReadLine());
                double keskmine = värvitud_põrand / XkgVärv;   
                
                Console.WriteLine("1kg värviga saab värvida " + värvitud_põrand / XkgVärv + "m põrandat");
                Console.WriteLine(Math.Round(põranda_pikkus / keskmine,1) + "kg värvi on vaja, et värvida " + põranda_pikkus + "m põrandat");
                Console.WriteLine(Math.Round(põranda_pikkus / keskmine,1) - XkgVärv + "kg värvi on vaja, et värvida ülejäänud põrand " + (põranda_pikkus - värvitud_põrand) + "m");
            }

        static void Alg_02()                // Harjutus 85
        {
            
            double keskmine, mahuti_maht, B_tonn_bensiin, kg_bensiini, B_tonn_bensiin_arvutuslik, liiter;

            liiter = 8;
            kg_bensiini = 5.68;
            keskmine = liiter / kg_bensiini;

            Console.WriteLine("1 kg bensiini on keskmiselt " + Math.Round(keskmine, 2) + " liitrit");
            Console.WriteLine("Sisesta mahuti maht m3");
            mahuti_maht = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Siia mahub maksimaalselt " + (B_tonn_bensiin_arvutuslik = mahuti_maht / keskmine) + " tonni bensiini.");
            Console.WriteLine("Sisesta bensiini kogus tonnides");
            B_tonn_bensiin = Convert.ToDouble(Console.ReadLine());

            if (B_tonn_bensiin_arvutuslik > B_tonn_bensiin)
                {
                Console.WriteLine("See on piisav " + B_tonn_bensiin + " tonni bensiini jaoks");
                }
            else
            {
                Console.WriteLine("Ei mahu");
                return;
            }

        }

        static void Alg_03()               // Harjutus 159
        {

            //Console.WriteLine("\n Jagatud 4: ");        // 16  20  28  32  40  44  52  56  64  68  76  80  88  92

            Console.WriteLine("\n Jagatud 4 ja mitte 6: ");

            for (int i = 10; i <= 99; i++)
            {
                if (i % 4 == 0)
                {
                    

                    if (i % 6 != 0)
                    {
                        Console.WriteLine(i);
                    }
                }
            }




        }
    }

}
    

